# -*- coding: utf-8 -*-
# @Author:viola@aoitech.net
# Copyright (c) 2020-2025 viola
# @Date Time:2022/05/05 12:11:25
# @File Name:__init__.py
"""Code Description:
"""

from performance.timer import Timer
__all__ = ["Timer"]

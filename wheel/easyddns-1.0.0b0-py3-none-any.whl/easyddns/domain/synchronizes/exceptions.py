# -*- coding: utf-8 -*-
# @Author:viola@aoitech.net
# Copyright (c) 2020-2025 viola
# @Date Time:2022/05/05 15:48:55
# @File Name:exceptions.py
"""All Exceptions
"""


class SynchronizerError(Exception):
    """synchronizer logic error
    """

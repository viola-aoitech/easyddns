# -*- coding: utf-8 -*-
# @Author:viola@aoitech.net
# Copyright (c) 2020-2025 viola
# @Date Time:2022/04/27 00:05:13
# @File Name:__init__.py
"""
Easy Dynamic Name Resolveing Toolkit and Client
~~~~~~~~~~~~~~~~~~~~~
"""

__version__ = '1.0.0 beta'

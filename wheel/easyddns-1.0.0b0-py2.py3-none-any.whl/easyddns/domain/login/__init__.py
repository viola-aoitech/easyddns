# -*- coding: utf-8 -*-
# @Author:viola@aoitech.net
# Copyright (c) 2020-2025 viola
# @Date Time:2022/05/05 15:05:22
# @File Name:__init__.py
"""
Easy Login Domain Model
"""
from easyddns.domain.login.record import Login

__all__ = ["Login"]
